These are small subsets of the MNIST data set, transformed into CSV, and made available for easy testing as your code develops.

The full dataset in CSV format is available at: http://pjreddie.com/projects/mnist-in-csv/
